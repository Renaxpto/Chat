import React from "react";
import type { ScreenProps } from "../types";
import HeaderTitle from "../layout/HeaderTitle";

export const ContactsScreen: React.FC<ScreenProps> = ({ goBack, goTo }) => (
  <div className="screen">
    <HeaderTitle title="Contactos" onBack={goBack} />

    <section className="card">
      <h3 className="card-title">Câmara Municipal</h3>
      <p className="card-text">Telefone: 000 000 000</p>
      <p className="card-text">Email: geral@cm-exemplo.pt</p>
      <p className="card-text">Morada: Rua Exemplo 123, Ponte de Lima</p>
      <p className="card-text">Horário: 09h00 - 17h30 (dias úteis)</p>
    </section>

    <section className="card">
      <h3 className="card-title">Balcão Único</h3>
      <p className="card-text">Telefone: 000 000 111</p>
      <p className="card-text">Email: balcao.unico@cm-exemplo.pt</p>
      <p className="card-text">Horário: 09h00 - 16h30 (dias úteis)</p>
      <button
        type="button"
        className="link-btn"
        onClick={() => goTo("onlineContact")}
      >
        Marcar atendimento (online)
      </button>
    </section>

    <section className="card">
      <h3 className="card-title">Outros contactos úteis</h3>
      <ul className="list">
        <li>
          Proteção Civil Municipal –{" "}
          <span className="card-text">Telefone: 000 000 222</span>
        </li>
        <li>
          Serviços de Águas e Saneamento –{" "}
          <span className="card-text">Telefone: 000 000 333</span>
        </li>
        <li>
          Ambiente e Espaços Verdes –{" "}
          <span className="card-text">Telefone: 000 000 444</span>
        </li>
      </ul>
    </section>

    <section className="card">
      <h3 className="card-title">Atendimento online</h3>
      <p className="card-text">
        Podes utilizar o atendimento online para esclarecer dúvidas simples ou
        pedir informações sobre serviços municipais.
      </p>
      <button
        type="button"
        className="primary-btn"
        onClick={() => goTo("onlineContact")}
      >
        Iniciar contacto online
      </button>
    </section>

    <section className="card">
      <h3 className="card-title">Redes sociais</h3>
      <p className="card-text">
        Acompanha as novidades do município através das redes sociais:
      </p>
      <ul className="list">
        <li>Facebook – @cm-exemplo</li>
        <li>Instagram – @cm-exemplo</li>
        <li>YouTube – Câmara Municipal Exemplo</li>
      </ul>
    </section>
  </div>
);

export default ContactsScreen;
